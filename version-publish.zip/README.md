# version-publish
## 前端配置环境
1. 首先安装nodejs，并配置环境变量
2. 在终端执行
```
cd verson
npm install
```
4. 开始编译项目
```
npm run build
```
输出到`resources/static`目录下

# 其他参考
## Project setup
```
npm install
```
### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```
输出编译项目到`vue.config.js`的`outputDir`配置当中

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
