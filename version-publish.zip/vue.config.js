module.exports = {
  publicPath: '',
  outputDir: 'D:\\sts-workspaces\\VersionPublish\\src\\main\\resources\\static',
  configureWebpack: {
    devtool: 'source-map'
  }
}