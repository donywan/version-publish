<template>
  <div>
    <h2>hello world</h2>
  </div>
</template>
<script>
export default {
  name: 'Test'
  
};
</script>