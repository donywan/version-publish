export default [
  { path: '/dashboard/home', name: '主页', icon: 'home' },
  { path: '/dashboard/version', name: '版本记录', icon: 'home' },
  { path: '/dashboard/test', name: '测试环境', icon: 'test'},
  { path: '/dashboard/about', name: '关于',icon:'about'}
]
