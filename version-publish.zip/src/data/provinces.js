export default [
    {
        label: '北京',
        value: '北京'
    },
    {
        label: '天津',
        value: 'tianjin',
    },
    {
        label: '河北',
        value: 'hebei'
    },
    {
        label: '山西',
        value: 'shanxi'
    },
    {
        label: '内蒙古',
        value: 'neimenggu'
    },
    {
        label: '吉林',
        value: 'jilin'
    },
    {
        label: '辽宁',
        value: 'liaoning'
    },
    {
        label: '上海',
        value: 'shanghai'
    },
    {
        label: '山东',
        value: 'shandong'
    },
    {
        label: '江苏',
        value: 'jiangsu'
    },
    {
        label: '安徽',
        value: 'anhui'
    },
    {
        label: '浙江',
        value: '浙江'
    },
    {
        label: '江西',
        value: 'jiangxi'
    },
    {
        label: '福建',
        value: 'fujian'
    },
    {
        label: '河南',
        value: 'henan'
    },
    {
        label: '湖北',
        value: 'hubei'
    },
    {
        label: '湖南',
        value: 'hunan'
    },
    {
        label: '海南',
        value: 'hainan'
    },
    {
        label: '广西',
        value: 'guangxi'
    },
    {
        label: '广东',
        value: 'guangdong'
    },
    {
        label: '重庆',
        value: 'chongqing'
    },
    {
        label: '四川',
        value: 'sichuan'
    },
    {
        label: '贵州',
        value: 'guizhou'
    },
    {
        label: '云南',
        value: 'yunnan'
    },
    {
        label: '西藏',
        value: '西藏'
    },
    {
        label: '陕西',
        value: 'sxi'
    },
    {
        label: '甘肃',
        value: 'gansu'
    },
    {
        label: '宁夏',
        value: 'ningxia'
    },
    {
        label: '青海',
        value: 'qinghai'
    },
    {
        label: '新疆',
        value: 'xinjiang'
    },
]