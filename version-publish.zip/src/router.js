import Vue from 'vue'
import Router from 'vue-router'
import Layout from './components/layout/Layout.vue';

Vue.use(Router)

export default new Router({
  routes: [
    { path:'/login',component:() => import('./views/Login1.vue')},
    { path: '/', redirect: '/dashboard' },
    {
      path: '/dashboard',
      component: Layout,
      children: [
        { path: 'version', component: () => import('./components/VersionTable.vue') },
        { path: 'home', component: () => import('./views/Home.vue') },
        { path: 'test', component: () => import('./components/Test') },
        { path: 'about', component: () => import('./views/About.vue') }
      ]
    },
  ]
})
